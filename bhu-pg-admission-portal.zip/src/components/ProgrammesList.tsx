import { useState } from "react";
import { Search, X, BookOpen, Clock, Landmark, FileText, ChevronRight } from "lucide-react";
import { BHU_PROGRAMMES, Programme } from "../data";

export default function ProgrammesList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [degreeFilter, setDegreeFilter] = useState("All");

  // Get unique degree types for filtering
  const degrees = ["All", ...Array.from(new Set(BHU_PROGRAMMES.map((p) => p.degree)))];

  // Filter programmes
  const filteredProgrammes = BHU_PROGRAMMES.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      p.department.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      p.testSubjects.toLowerCase().includes(searchQuery.toLowerCase().trim());

    const matchesDegree = degreeFilter === "All" || p.degree === degreeFilter;

    return matchesSearch && matchesDegree;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Search Header Banner */}
      <div className="bg-[#3e1300] text-white rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden select-none">
        <div className="absolute right-0 top-0 w-36 h-36 bg-orange-400 rounded-full blur-[50px] opacity-35" />
        <h3 className="text-xl md:text-2xl font-bold font-headline mb-2">Browse PG Programmes Offered by BHU</h3>
        <p className="text-white/80 text-xs md:text-sm max-w-2xl leading-relaxed">
          Search and view course eligibility requirements, departments, semesters, fee structures, and required CUET-PG subject test papers.
        </p>
      </div>

      {/* Filter Options and Search Bar row */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-8 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="form-control pl-10 pr-10"
            placeholder="Search by code, title, subject paper..."
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <Search size={16} />
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 bg-transparent border-0 p-1 cursor-pointer"
            >
              <X size={15} />
            </button>
          )}
        </div>

        {/* Degree filter tabs */}
        <div className="flex flex-wrap gap-2">
          {degrees.map((deg) => (
            <button
              key={deg}
              onClick={() => setDegreeFilter(deg)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all border-0 cursor-pointer ${
                degreeFilter === deg
                  ? "bg-[#f4811f] text-white shadow-sm"
                  : "bg-gray-100 hover:bg-gray-200 text-gray-700"
              }`}
            >
              {deg}
            </button>
          ))}
        </div>
      </div>

      {/* Filtered course catalogue view */}
      {filteredProgrammes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredProgrammes.map((p) => (
            <div
              key={p.code}
              className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Degree tags */}
                <div className="flex justify-between items-start">
                  <span className="bg-[#f4811f]/10 text-[#f4811f] text-[10px] uppercase font-bold tracking-wider px-3 py-1 rounded-md">
                    {p.degree}
                  </span>
                  <span className="text-gray-400 font-bold text-xs uppercase tracking-wide font-mono">
                    {p.code}
                  </span>
                </div>

                {/* Course Name */}
                <div>
                  <h4 className="font-bold text-[#3e1300] text-sm md:text-base leading-snug font-headline">
                    {p.name}
                  </h4>
                  <p className="text-gray-400 text-xs mt-0.5 font-medium">{p.department}</p>
                </div>

                {/* Eligibility criteria highlight */}
                <div className="bg-orange-500/5 p-3.5 rounded-xl border border-orange-500/10 text-xs leading-relaxed text-gray-700">
                  <p className="font-bold text-[#3e1300] text-[11px] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                    <FileText size={12} className="text-[#f4811f]" />
                    Aggregate Minimum Eligibility
                  </p>
                  <span>{p.eligibility}</span>
                </div>

                {/* Metrics: duration, test code, fee */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl flex items-center gap-2">
                    <Clock size={15} className="text-[#f4811f] flex-shrink-0" />
                    <div>
                      <p className="text-gray-400 text-[10px] leading-none uppercase font-bold">Duration</p>
                      <p className="text-gray-800 font-semibold mt-1 leading-none">{p.duration}</p>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 border border-gray-100 rounded-xl flex items-center gap-2">
                    <Landmark size={15} className="text-[#f4811f] flex-shrink-0" />
                    <div>
                      <p className="text-gray-400 text-[10px] leading-none uppercase font-bold">Fees Rate</p>
                      <p className="text-gray-800 font-semibold mt-1 leading-none">{p.fee}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Required CUET subject paper component */}
              <div className="border-t border-gray-100 pt-4 mt-5 flex justify-between items-center text-xs">
                <div>
                  <p className="text-gray-400 text-[10px] uppercase font-bold">Required CUET Test Paper Code</p>
                  <p className="text-[#f4811f] font-bold mt-1 text-[13px]">{p.testSubjects}</p>
                </div>

                <div className="text-gray-300">
                  <ChevronRight size={20} />
                </div>
              </div>

            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center shadow-sm select-none">
          <p className="font-bold text-[#3e1300] text-sm md:text-base uppercase tracking-wider mb-2">No Matching Programmes Found</p>
          <p className="text-gray-400 text-xs md:text-sm font-medium">Try verifying your spelling or adjusting of filter degree types.</p>
        </div>
      )}

    </div>
  );
}
