import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, ChevronUp, ShieldCheck, ShieldAlert, Sparkles, Scale, Info } from "lucide-react";

interface TopbarProps {
  fontSizeOffset: number;
  setFontSizeOffset: (offset: number) => void;
}

export default function Topbar({ fontSizeOffset, setFontSizeOffset }: TopbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-[#3e1300] text-gray-200 text-xs py-2 px-4 shadow-sm z-50 relative">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
        {/* Left Side: Indian Flag and Academic Portal Verification */}
        <div className="flex items-center gap-2 md:gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            {/* National Tricolour Flag SVG */}
            <span className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="20" height="20" className="rounded-sm">
                <rect width="128" height="42.6" fill="#FF9933" />
                <rect y="42.6" width="128" height="42.6" fill="#FFFFFF" />
                <rect y="85.2" width="128" height="42.8" fill="#128807" />
                <g transform="translate(64,64)">
                  <circle r="12" fill="none" stroke="#000080" strokeWidth="1.5" />
                  <circle r="2.5" fill="#000080" />
                  {Array.from({ length: 24 }).map((_, i) => (
                    <line
                      key={i}
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="-12"
                      stroke="#000080"
                      strokeWidth="0.8"
                      transform={`rotate(${(i * 360) / 24})`}
                    />
                  ))}
                </g>
              </svg>
            </span>
            <p className="mb-0 text-white font-medium text-[10px] md:text-xs">
              This is the <span className="underline">official website</span> of an Academic Institution.
            </p>
          </div>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="bg-white/10 hover:bg-white/15 text-white rounded px-2.5 py-1 flex items-center gap-1 transition-all"
            id="howToKnowBtn"
          >
            <span className="text-[10px] font-bold tracking-wider">Here&apos;s how you know</span>
            {isOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
        </div>

        {/* Right Side: Text Size Adjusters & Indian Emblem / Ministry note */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 font-mono">
            <button
              onClick={() => setFontSizeOffset(Math.max(-2, fontSizeOffset - 1))}
              className={`px-2 py-0.5 rounded transition ${
                fontSizeOffset === -1 ? "bg-white/20 text-white font-bold" : "hover:bg-white/10 text-gray-300"
              }`}
              id="txtDecrease"
              title="Decrease Font Size"
            >
              A-
            </button>
            <button
              onClick={() => setFontSizeOffset(0)}
              className={`px-2 py-0.5 rounded transition ${
                fontSizeOffset === 0 ? "bg-white/20 text-white font-bold" : "hover:bg-white/10 text-gray-300"
              }`}
              id="txtOrig"
              title="Reset Font Size"
            >
              A
            </button>
            <button
              onClick={() => setFontSizeOffset(Math.min(3, fontSizeOffset + 1))}
              className={`px-2 py-0.5 rounded transition ${
                fontSizeOffset === 1 ? "bg-white/20 text-white font-bold" : "hover:bg-white/10 text-gray-300"
              }`}
              id="txtIncrease"
              title="Increase Font Size"
            >
              A+
            </button>
          </div>
        </div>
      </div>

      {/* Collapsible Security and Domain Verification Info */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden border-t border-white/10 mt-2 bg-[#2d0a00]/40 rounded-b-lg"
          >
            <div className="max-w-7xl mx-auto py-4 px-4 grid grid-cols-1 md:grid-cols-3 gap-6 text-gray-300">
              <div className="flex gap-3">
                <div className="p-2 bg-white/10 rounded-full h-fit text-amber-500">
                  <Scale size={20} />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold leading-relaxed mb-1">
                    Official Academic Domains <span className="text-[#f4811f]">.ac.in or .edu.in</span>
                  </h4>
                  <p className="text-[11px] leading-relaxed text-gray-300">
                    Academic institution websites in India usually use <strong>.ac.in</strong> or <strong>.edu.in</strong>. Always check the URL carefully before sharing any academic credentials.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="p-2 bg-[#f4811f]/20 rounded-full h-fit text-[#f4811f]">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold leading-relaxed mb-1">
                    Admission Portals for HEIs <span className="text-[#f4811f]">on Samarth</span>
                  </h4>
                  <p className="text-[11px] leading-relaxed text-gray-300">
                    The Admission Portal for Higher Education Institutions on Samarth follow the domain nomenclature 
                    as <code>{"{institute_short_code}.samarth.edu.in"}</code>.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="p-2 bg-green-500/20 rounded-full h-fit text-green-400">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold leading-relaxed mb-1">
                    Secure Connection <span className="text-[#f4811f]">SSL Encrypted (HTTPS)</span>
                  </h4>
                  <p className="text-[11px] leading-relaxed text-gray-300">
                    The lock icon (🔒) or <strong>https://</strong> in the address bar indicates an encrypted, secure connection. Your private transactions remain fully confidential.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
