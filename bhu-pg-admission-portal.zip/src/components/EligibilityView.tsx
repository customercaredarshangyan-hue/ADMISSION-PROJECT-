import { useState } from "react";
import { Search, Info, HelpCircle, FileSpreadsheet, CheckCircle } from "lucide-react";
import { BHU_PROGRAMMES } from "../data";

export default function EligibilityView() {
  const [searchFilter, setSearchFilter] = useState("");

  const filteredProgrammes = BHU_PROGRAMMES.filter((p) =>
    p.name.toLowerCase().includes(searchFilter.toLowerCase().trim()) ||
    p.code.toLowerCase().includes(searchFilter.toLowerCase().trim()) ||
    p.testSubjects.toLowerCase().includes(searchFilter.toLowerCase().trim())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      
      {/* Header section */}
      <div className="bg-[#3e1300] text-white rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden select-none">
        <div className="absolute right-0 top-0 w-36 h-36 bg-orange-400 rounded-full blur-[50px] opacity-35" />
        <h3 className="text-xl md:text-2xl font-bold font-headline mb-2 flex items-center gap-2">
          <FileSpreadsheet size={24} className="text-[#f4811f]" />
          Eligibility Criteria List
        </h3>
        <p className="text-white/85 text-xs md:text-sm max-w-2xl leading-relaxed">
          Verify qualifying graduation benchmarks and matching CUET (PG) test domains before submitting application preferences.
        </p>
      </div>

      {/* Search Input bar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-8">
        <div className="relative max-w-md">
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="form-control pl-10 pr-10"
            placeholder="Search criteria by program name or code..."
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <Search size={16} />
          </div>
          {searchFilter && (
            <button
              onClick={() => setSearchFilter("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 bg-transparent border-0 p-1 cursor-pointer"
            >
              <HelpCircle size={15} />
            </button>
          )}
        </div>
      </div>

      {/* Grid or Table representing guidelines */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="table-responsive">
          <table className="table table-hover align-middle mb-0 text-left">
            <thead className="table-light bg-gray-50 border-bottom">
              <tr className="text-[#3e1300] font-bold text-xs uppercase tracking-wider">
                <th className="py-4 px-6 w-24">Code</th>
                <th className="py-4 px-6 w-64">PG Programme name</th>
                <th className="py-4 px-6">Graduation Eligibility Requirement</th>
                <th className="py-4 px-6 w-56">Required CUET Test Paper</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-xs md:text-[13px] text-gray-700">
              {filteredProgrammes.length > 0 ? (
                filteredProgrammes.map((p) => (
                  <tr key={p.code} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-gray-400 select-none">
                      {p.code}
                    </td>
                    <td className="py-4 px-6">
                      <p className="font-bold text-[#3e1300] font-headline">{p.name}</p>
                      <p className="text-gray-400 text-[11px] mt-0.5">{p.department}</p>
                    </td>
                    <td className="py-4 px-6 leading-relaxed">
                      <div className="flex gap-2">
                        <CheckCircle size={14} className="text-green-500 flex-shrink-0 mt-1" />
                        <span>{p.eligibility}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-[#f4811f] font-bold">
                      {p.testSubjects}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-gray-400 select-none">
                    <p className="font-bold text-xs uppercase tracking-wider">No matching course eligibility parameters found.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
