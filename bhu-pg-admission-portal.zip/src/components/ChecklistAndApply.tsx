import { 
  UserPlus, 
  Download, 
  Calendar, 
  LogIn, 
  Paperclip, 
  Camera, 
  FileCheck, 
  BookOpen, 
  Briefcase 
} from "lucide-react";

interface ChecklistAndApplyProps {
  onOpenLogin: () => void;
  onOpenRegister: () => void;
}

export default function ChecklistAndApply({ onOpenLogin, onOpenRegister }: ChecklistAndApplyProps) {
  return (
    <div className="space-y-6">
      
      {/* Apply For Admissions Call-to-action Banner */}
      <div className="bg-[#f4811f] text-white rounded-2xl p-6 md:p-8 shadow-sm relative overflow-hidden select-none">
        {/* Abstract subtle mesh background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(255,255,255,0.1),transparent_50%)] pointer-events-none" />
        
        <h4 className="text-lg md:text-xl font-bold font-headline mb-2 leading-tight">
          Apply For Admissions (CAP-PG)
        </h4>
        <p className="text-white/85 text-[12px] md:text-xs leading-relaxed max-w-xl mb-6">
          Join our PG Admission Combined Allotment Program (CAP-PG) 2026-27 Academic Cycle. Offer your course preferences, upload verifiable marksheets, and secure your future in India&apos;s premier Central University.
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={onOpenRegister}
            className="btn btn-light bg-white hover:bg-gray-50 text-[#f4811f] px-5 py-2.5 rounded-xl font-bold text-xs inline-flex items-center gap-2 transition-all transform active:scale-95 shadow-sm border-0 cursor-pointer"
          >
            <UserPlus size={15} />
            NEW REGISTRATION
          </button>
          
          <a
            href="https://api.bhu.edu.in/uploads/PG_Bulletin_2026_Final_compressed_26f59826df.pdf"
            target="_blank"
            rel="noreferrer"
            className="btn border-soft-new hover:bg-white/10 text-white border border-white/20 px-5 py-2.5 rounded-xl font-bold text-xs inline-flex items-center justify-center gap-2 transition-all text-decoration-none cursor-pointer"
          >
            <Download size={15} />
            Prospectus
          </a>
        </div>
      </div>

      {/* Quick Dates / Entry Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Deadline Segment */}
        <div className="bg-red-50 border border-red-500/10 rounded-2xl p-4.5 flex gap-3.5 items-center relative overflow-hidden">
          <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 animate-ping" />
          <div className="h-11 w-11 bg-red-100 text-red-600 rounded-xl flex items-center justify-center">
            <Calendar size={20} />
          </div>
          <div>
            <h6 className="font-bold text-gray-900 text-xs md:text-sm m-0">Portal Deadline</h6>
            <p className="text-red-600 text-xs font-bold mt-0.5">04 June, 2026</p>
          </div>
        </div>

        {/* Existing Users segment */}
        <button
          onClick={onOpenLogin}
          className="bg-orange-50 border border-orange-500/10 rounded-2xl p-4.5 flex gap-3.5 items-center text-left hover:bg-orange-100/30 transition-all border-0 w-full"
        >
          <div className="h-11 w-11 bg-orange-100 text-[#f4811f] rounded-xl flex items-center justify-center">
            <LogIn size={20} />
          </div>
          <div>
            <h6 className="font-bold text-gray-900 text-xs md:text-sm m-0">Existing Users</h6>
            <p className="text-[#f4811f] text-xs font-bold mt-0.5 inline-flex items-center gap-1">
              Login to Candidate Dashboard &rarr;
            </p>
          </div>
        </button>

      </div>

      {/* Document Checklist Card */}
      <div className="card shadow rounded-2xl border-0 overflow-hidden bg-white">
        <div className="card-header px-4 py-3.5 bg-white border-bottom flex items-center gap-2 font-headline uppercase select-none">
          <Paperclip size={16} className="text-[#f4811f]" />
          <span className="font-bold text-gray-900 text-xs md:text-sm">Document Checklist & Upload Details</span>
        </div>

        <div className="card-body p-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Scanned Photo */}
            <div className="p-3.5 bg-gray-50 border border-gray-100 rounded-xl flex items-start gap-3">
              <Camera size={20} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
              <div>
                <h6 className="font-semibold text-gray-900 text-xs md:text-[13px] mb-1">Passport Photograph</h6>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                  Recent color photo on white background. Supported: JPEG ({`<=`}1024 KB)
                </p>
              </div>
            </div>

            {/* Scanned Signature */}
            <div className="p-3.5 bg-gray-50 border border-gray-100 rounded-xl flex items-start gap-3">
              <FileCheck size={20} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
              <div>
                <h6 className="font-semibold text-gray-900 text-xs md:text-[13px] mb-1">Scanned Signature</h6>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                  Clear sign on plain white sheet. Supported: JPEG ({`<=`}1024 KB)
                </p>
              </div>
            </div>

            {/* Educational Marksheets */}
            <div className="p-3.5 bg-gray-50 border border-gray-100 rounded-xl flex items-start gap-3">
              <BookOpen size={20} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
              <div>
                <h6 className="font-semibold text-gray-900 text-xs md:text-[13px] mb-1">Graduate Marksheets</h6>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                   Consolidated degree/semester marksheets. Supported: PDF ({`<=`}1024 KB)
                </p>
              </div>
            </div>

            {/* Category / Caste Cert */}
            <div className="p-3.5 bg-gray-50 border border-gray-100 rounded-xl flex items-start gap-3">
              <Briefcase size={20} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
              <div>
                <h6 className="font-semibold text-gray-900 text-xs md:text-[13px] mb-1">Category Certificate</h6>
                <p className="text-gray-500 text-[11px] leading-relaxed">
                  OBC-NCL, EWS, SC, ST or PwBD proofs. Supported: PDF ({`<=`}1024 KB)
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>

    </div>
  );
}
