import { useState } from "react";
import { Search, X, HelpCircle, ChevronDown, ChevronUp, Clock, Info } from "lucide-react";
import { HELP_CENTER_FAQS, FaqItem } from "../data";
import { motion, AnimatePresence } from "motion/react";

export default function HelpCenter() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(null);

  // Group FAQ categories
  const categories = ["All", ...Array.from(new Set(HELP_CENTER_FAQS.map((faq) => faq.category)))];

  // Filtering criteria
  const filteredFaqs = HELP_CENTER_FAQS.filter((faq) => {
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase().trim());
    const matchesCategory = activeCategory === "All" || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleExpand = (id: string) => {
    setExpandedFaqId(expandedFaqId === id ? null : id);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      
      {/* Help Banner Header */}
      <div className="bg-[#3e1300] text-white rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden select-none">
        <div className="absolute right-0 top-0 w-36 h-36 bg-orange-400 rounded-full blur-[50px] opacity-35" />
        <h3 className="text-xl md:text-2xl font-bold font-headline mb-2 flex items-center gap-2">
          <HelpCircle size={24} className="text-[#f4811f]" />
          Candidate Help Center (FAQs)
        </h3>
        <p className="text-white/85 text-xs md:text-sm max-w-2xl leading-relaxed">
          Need assistance with counseling queries, document guidelines, and registration details? Find resolutions to common doubts quickly.
        </p>
      </div>

      {/* Filter and Search Panels */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 mb-8 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="form-control pl-10 pr-10"
            placeholder="Search help topics..."
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
            <Search size={16} />
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 bg-transparent border-0 p-1 cursor-pointer"
            >
              <X size={15} />
            </button>
          )}
        </div>

        {/* Category triggers */}
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all border-0 cursor-pointer ${
                activeCategory === cat
                  ? "bg-[#f4811f] text-white shadow-sm"
                  : "bg-gray-100 hover:bg-gray-200 text-gray-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Accordion FAQ block */}
      {filteredFaqs.length > 0 ? (
        <div className="space-y-4">
          {filteredFaqs.map((faq) => {
            const isExpanded = expandedFaqId === faq.id;

            return (
              <div
                key={faq.id}
                className="bg-white border border-gray-100 rounded-xl overflow-hidden shadow-xs hover:border-[#f4811f]/30 transition-all"
              >
                {/* Accordion Trigger */}
                <button
                  onClick={() => toggleExpand(faq.id)}
                  className="w-full text-left px-5 py-4 flex items-center justify-between gap-4 bg-transparent border-0 cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <span className="p-1 px-2.5 bg-orange-500/10 text-orange-600 font-bold text-[10px] rounded uppercase tracking-wider select-none">
                      {faq.category}
                    </span>
                    <span className="font-bold text-[#3e1300] text-xs md:text-sm leading-snug font-headline">
                      {faq.question}
                    </span>
                  </div>
                  <span className="text-gray-400">
                    {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </span>
                </button>

                {/* Collapsible Answer area */}
                <AnimatePresence initial={false}>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                    >
                      <div className="px-5 pb-4 border-t border-gray-50 pt-3 bg-gray-50/50 text-[13px] md:text-sm leading-relaxed text-gray-600">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center shadow-sm select-none">
          <p className="font-bold text-[#3e1300] text-sm md:text-base uppercase tracking-wider mb-2">No Matching Answers Found</p>
          <p className="text-gray-400 text-xs md:text-sm font-medium">Try typing alternative terms or check other categories.</p>
        </div>
      )}

      {/* Support help panel bottom banner */}
      <div className="mt-12 bg-white rounded-2xl border border-gray-100 p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
            <Info size={20} />
          </div>
          <div>
            <h6 className="font-bold text-gray-900 text-xs md:text-sm m-0">Still require support assistance?</h6>
            <p className="text-gray-400 text-xs mt-0.5">We usually respond within 4 business hours.</p>
          </div>
        </div>
        <p className="text-xs text-slate-800 font-semibold leading-relaxed m-0 bg-gray-50 border border-gray-100 p-2 px-3 rounded-xl">
           Counseling helpline email: &nbsp;
          <a href="mailto:admission.help@bhu.ac.in" className="underline font-bold text-[#f4811f]">
            admission.help@bhu.ac.in
          </a>
        </p>
      </div>

    </div>
  );
}
