import { useState, FormEvent } from "react";
import { X, LogIn, UserPlus, HelpCircle, ShieldCheck } from "lucide-react";

interface AuthModalsProps {
  showLogin: boolean;
  showRegister: boolean;
  onCloseLogin: () => void;
  onCloseRegister: () => void;
  onLoginSuccess: (name: string) => void;
}

export default function AuthModals({
  showLogin,
  showRegister,
  onCloseLogin,
  onCloseRegister,
  onLoginSuccess,
}: AuthModalsProps) {
  // Login States
  const [appNumber, setAppNumber] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Register States
  const [regName, setRegName] = useState("");
  const [regEmail, setRegNameEmail] = useState("");
  const [regAppNumber, setRegAppNumber] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [regError, setRegError] = useState("");

  const handleLoginSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!appNumber.trim() || !password.trim()) {
      setLoginError("Please enter both NTA Application Number and Password.");
      return;
    }
    // Simulate candidate lookup
    const name = regName.trim() || "Aman Kumar Sharma";
    onLoginSuccess(name);
    setAppNumber("");
    setPassword("");
    setLoginError("");
    onCloseLogin();
  };

  const handleRegisterSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim() || !regAppNumber.trim() || !regPassword.trim()) {
      setRegError("All fields must be fully completed.");
      return;
    }
    if (!termsAccepted) {
      setRegError("Please consent to the eligibility norms and terms of verification.");
      return;
    }

    // Register success simulated -> auto-log in!
    onLoginSuccess(regName.trim());
    setRegError("");
    onCloseRegister();
  };

  return (
    <>
      {/* 1. LOGIN MODAL */}
      {showLogin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl relative border border-gray-100 overflow-hidden animate-scale-up">
            {/* Modal Header */}
            <div className="px-5 py-4 bg-[#3e1300] text-white flex justify-between items-center">
              <h5 className="font-bold text-sm md:text-base font-headline m-0 flex items-center gap-2">
                <LogIn size={18} className="text-[#f4811f]" />
                Registered Candidate Login
              </h5>
              <button
                onClick={onCloseLogin}
                className="text-white/60 hover:text-white bg-transparent border-0 cursor-pointer"
                title="Close"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
              {loginError && (
                <div className="p-3 bg-red-500/10 text-red-600 rounded-lg text-xs font-semibold border border-red-500/15">
                  {loginError}
                </div>
              )}

              <div className="space-y-1">
                <label className="form-label">NTA CUET-PG Application No.</label>
                <div className="relative">
                  <input
                    type="text"
                    value={appNumber}
                    onChange={(e) => setAppNumber(e.target.value)}
                    placeholder="Enter Application No. (e.g., 26351002345)"
                    className="form-control"
                    required
                  />
                </div>
                <span className="text-[10px] text-gray-400 font-medium">Use Application number specified in your NTA scorecard</span>
              </div>

              <div className="space-y-1">
                <label className="form-label">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter counseling portal password"
                  className="form-control"
                  required
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full btn bg-[#f4811f] hover:bg-[#e07519] text-white font-bold py-2.5 text-xs tracking-wider"
                >
                  LOGIN DASHBOARD
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    onCloseLogin();
                    onCloseRegister(); // open register modal
                  }}
                  className="text-xs text-gray-500 hover:text-[#f4811f] font-semibold bg-transparent border-0 cursor-pointer underline"
                >
                  New candidates? Register here &rarr;
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. REGISTER/SIGN UP MODAL */}
      {showRegister && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs select-none">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl relative border border-gray-100 overflow-hidden animate-scale-up">
            {/* Modal Header */}
            <div className="px-5 py-4 bg-[#3e1300] text-white flex justify-between items-center">
              <h5 className="font-bold text-sm md:text-base font-headline m-0 flex items-center gap-2">
                <UserPlus size={18} className="text-[#f4811f]" />
                CAP-PG New Registration 2026
              </h5>
              <button
                onClick={onCloseRegister}
                className="text-white/60 hover:text-white bg-transparent border-0 cursor-pointer"
                title="Close"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleRegisterSubmit} className="p-6 space-y-4">
              {regError && (
                <div className="p-3 bg-red-500/10 text-red-600 rounded-lg text-xs font-semibold border border-red-500/15">
                  {regError}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="form-label">Full Candidate Name</label>
                  <input
                    type="text"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="As in NTA Admit Card"
                    className="form-control"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="form-label">Active Email ID</label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegNameEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="form-control"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="form-label">NTA CUET-PG Application No.</label>
                  <input
                    type="text"
                    value={regAppNumber}
                    onChange={(e) => setRegAppNumber(e.target.value)}
                    placeholder="11-digit application number"
                    className="form-control"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="form-label">Set Portal Password</label>
                  <input
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Min 6 characters limit"
                    className="form-control"
                    required
                  />
                </div>
              </div>

              {/* Consent Terms Checklist */}
              <div className="p-4 bg-gray-50 border border-gray-100 rounded-xl">
                <div className="flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    id="acceptTerms"
                    checked={termsAccepted}
                    onChange={(e) => setTermsAccepted(e.target.checked)}
                    className="mt-1"
                  />
                  <label htmlFor="acceptTerms" className="text-gray-600 text-xs leading-relaxed font-medium cursor-pointer">
                    I declare that I have selects <strong>Banaras Hindu University</strong> in my NTA application form, appeared in correct test papers, and fulfill the qualifying graduation criteria specified in the Information Bulletin.
                  </label>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={onCloseRegister}
                  className="px-4 py-2.5 rounded-lg border border-gray-200 text-gray-700 bg-white hover:bg-slate-50 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn bg-[#f4811f] hover:bg-[#e07519] text-white font-bold py-2.5 px-6 text-xs tracking-wider"
                >
                  REGISTER WITH CUET DETAILS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
