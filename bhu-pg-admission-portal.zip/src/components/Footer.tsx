import { GraduationCap, Mail, MapPin, ArrowRightSquare } from "lucide-react";

interface FooterProps {
  onViewChange: (view: string) => void;
}

export default function Footer({ onViewChange }: FooterProps) {
  const handleLinkClick = (view: string) => {
    onViewChange(view);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="footer-section mt-auto z-10 select-none">
      
      {/* 1. Indian Government & Ministry Auxiliary Footer Bar */}
      <div className="py-6 border-top bg-gray-100 text-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-wrap gap-8 items-center text-xs font-semibold">
            {/* National Portal */}
            <a 
              href="https://www.india.gov.in/" 
              target="_blank" 
              rel="noreferrer"
              className="text-gray-800 hover:text-orange-600 transition tracking-wide text-decoration-none"
            >
              <div className="font-hi font-bold text-gray-800">भारत सरकार</div>
              <div>Government of India</div>
            </a>

            <div className="hidden md:block h-6 w-px bg-gray-300" />

            {/* Ministry of Education */}
            <a 
              href="https://education.gov.in/" 
              target="_blank" 
              rel="noreferrer"
              className="text-gray-800 hover:text-orange-600 transition tracking-wide text-decoration-none"
            >
              <div className="font-hi font-bold text-gray-800">शिक्षा मंत्रालय</div>
              <div>Ministry of Education</div>
            </a>

            <div className="hidden md:block h-6 w-px bg-gray-300" />

            {/* Samarth Portal */}
            <a 
              href="https://samarth.edu.in/" 
              target="_blank" 
              rel="noreferrer"
              className="text-gray-800 hover:text-orange-600 transition tracking-wide text-decoration-none"
            >
              <div className="font-hi font-bold text-gray-800">समर्थ ई-गॉव</div>
              <div>Samarth eGov</div>
            </a>
          </div>
        </div>
      </div>

      {/* 2. Terracotta Brand Footer Area */}
      <div className="bg-[#3e1300] text-white pt-12 pb-6 border-top border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12">
            
            {/* Column 1: BHU branding and contact details */}
            <div className="lg:col-span-6 space-y-6">
              <div className="flex items-start gap-4">
                <div className="h-14 w-14 rounded-xl bg-white border border-white/10 flex items-center justify-center p-1.5 flex-shrink-0">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Banaras_Hindu_University_Logo.svg/512px-Banaras_Hindu_University_Logo.svg.png"
                    alt="BHU Logo"
                    className="img-fluid"
                    style={{ maxHeight: "100%", width: "auto" }}
                  />
                </div>
                <div>
                  <h5 className="font-bold text-white text-[15px] md:text-base font-headline mb-1">
                    Banaras Hindu University
                  </h5>
                  <p className="text-white/60 text-xs font-semibold uppercase tracking-wider">
                    PG Admission Combined Allotment Program (CAP-PG) 2026-27
                  </p>
                </div>
              </div>

              <div className="w-2/3 border-t border-white/10 my-4" />

              <div className="space-y-3 text-xs md:text-[13px] text-white/80 font-medium">
                <p className="flex items-start gap-2.5">
                  <MapPin size={16} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
                  <span>The Central Admission Committee, Banaras Hindu University, Varanasi-221005, Uttar Pradesh, INDIA</span>
                </p>
                <p className="flex items-start gap-2.5">
                  <Mail size={16} className="text-[#f4811f] flex-shrink-0 mt-0.5" />
                  <span>
                    Email Support: &nbsp;
                    <a href="mailto:admission.help@bhu.ac.in" className="text-white underline hover:text-[#f4811f] transition-all">
                      admission.help@bhu.ac.in
                    </a>
                  </span>
                </p>
              </div>
            </div>

            {/* Column 2: Portal links */}
            <div className="lg:col-span-3 space-y-4">
              <h5 className="font-bold text-sm md:text-[15px] text-white tracking-wide uppercase font-headline">
                Admission Portal Links
              </h5>
              <ul className="space-y-2.5 list-none pl-0 m-0 text-xs md:text-[13px]">
                <li>
                  <button 
                    onClick={() => handleLinkClick("home")}
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 bg-transparent border-0 p-0 text-left cursor-pointer font-medium"
                  >
                    <span>&rarr;</span> Public Notices
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleLinkClick("programmes")}
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 bg-transparent border-0 p-0 text-left cursor-pointer font-medium"
                  >
                    <span>&rarr;</span> Find Your Programme
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleLinkClick("eligibility")}
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 bg-transparent border-0 p-0 text-left cursor-pointer font-medium"
                  >
                    <span>&rarr;</span> Eligibility Programme List
                  </button>
                </li>
                <li>
                  <a 
                    href="https://api.bhu.edu.in/uploads/PG_Bulletin_2026_Final_compressed_26f59826df.pdf" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 text-decoration-none font-medium"
                  >
                    <span>&rarr;</span> Prospectus Bulletin
                  </a>
                </li>
                <li>
                  <a 
                    href="https://bhu.ac.in" 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 text-decoration-none font-medium"
                  >
                    <span>&rarr;</span> University Main Website
                  </a>
                </li>
                <li>
                  <button 
                    onClick={() => handleLinkClick("help-center")}
                    className="text-white/65 hover:text-white transition flex items-center gap-1.5 bg-transparent border-0 p-0 text-left cursor-pointer font-medium"
                  >
                    <span>&rarr;</span> Help Center (FAQs)
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Secondary Links */}
            <div className="lg:col-span-3 space-y-4">
              <h5 className="font-bold text-sm md:text-[15px] text-white tracking-wide uppercase font-headline">
                Other Important Links
              </h5>
              <p className="text-white/40 text-xs italic font-medium">No external links configured</p>
            </div>

          </div>

          <div className="border-t border-white/10 my-8" />

          {/* Copyright disclosures */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-white/50 font-medium">
            <div>
              <span>Content Owned &amp; Authored by </span>
              <a 
                href="https://bhu.ac.in" 
                target="_blank" 
                rel="noreferrer"
                className="text-white hover:text-white/80 transition-all text-decoration-none font-bold"
              >
                Banaras Hindu University
              </a>
            </div>
            
            <div className="text-center md:text-right space-y-1">
              <p className="mb-0">
                Designed &amp; Developed by &nbsp;
                <a 
                  href="https://samarth.edu.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-white hover:text-white/80 transition-all text-decoration-none font-bold"
                >
                  Samarth eGov
                </a>
              </p>
              <p className="mb-0">
                An Initiative of the &nbsp;
                <a 
                  href="https://education.gov.in" 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-white hover:text-white/80 transition-all text-decoration-none font-bold"
                >
                  Ministry of Education, Govt. of India
                </a>
              </p>
            </div>
          </div>

        </div>
      </div>

    </footer>
  );
}
