import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, ArrowRight, CornerDownRight } from "lucide-react";
import { FEATURED_ANNOUNCEMENTS } from "../data";

interface HeroSliderProps {
  onViewChange: (view: string) => void;
}

export default function HeroSlider({ onViewChange }: HeroSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % FEATURED_ANNOUNCEMENTS.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + FEATURED_ANNOUNCEMENTS.length) % FEATURED_ANNOUNCEMENTS.length);
  };

  // Auto-play the slider every 6 seconds
  useEffect(() => {
    const timer = setInterval(nextSlide, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative bg-gradient-to-br from-amber-50 to-orange-100/50 rounded-2xl border-2 border-orange-500/20 p-6 md:p-8 min-h-[320px] flex flex-col justify-between overflow-hidden shadow-sm">
      {/* Background ambient lighting orb */}
      <div className="absolute right-0 top-0 w-44 h-44 bg-orange-300 rounded-full blur-[70px] opacity-45 pointer-events-none" />

      {/* Main Slide Content Area */}
      <div className="relative z-10 flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="space-y-4"
          >
            <div className="flex items-center gap-3">
              {/* Slide Number indicator */}
              <div className="h-11 w-11 rounded-xl bg-orange-500/10 text-orange-600 font-bold border border-orange-500/15 flex items-center justify-center font-headline select-none">
                {currentIndex + 1}.
              </div>
              <span className="bg-[#f4811f] text-white text-[10px] font-bold tracking-wider px-3.5 py-1 rounded-md uppercase select-none">
                Featured Notice
              </span>
            </div>

            <div className="pt-2">
              <h3 className="text-[#3e1300] font-bold text-lg md:text-xl font-headline tracking-tight leading-snug">
                {FEATURED_ANNOUNCEMENTS[currentIndex].title}
              </h3>
              <p className="text-gray-500 text-xs md:text-sm font-medium mt-1">
                Announced &bull; {FEATURED_ANNOUNCEMENTS[currentIndex].date} ({FEATURED_ANNOUNCEMENTS[currentIndex].dateLabel})
              </p>
            </div>

            <div className="pt-4">
              <a
                href={FEATURED_ANNOUNCEMENTS[currentIndex].documentUrl}
                className="btn-apply btn-sm inline-flex items-center gap-2 bg-[#f4811f] text-white text-xs font-bold py-2 text-decoration-none shadow"
              >
                View Announcement <CornerDownRight size={13} />
              </a>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Footer Navigation controls matching Samarth's design */}
      <div className="relative z-10 flex items-center justify-between border-t border-orange-500/10 pt-4 mt-6">
        <div className="flex items-center gap-3">
          {/* Back Arrow */}
          <button
            onClick={prevSlide}
            className="h-8 w-8 rounded-lg border border-orange-500/20 text-[#f4811f] bg-white hover:bg-orange-50 transition flex items-center justify-center p-0"
            title="Previous Notice"
          >
            <ArrowLeft size={14} />
          </button>

          {/* Dots Pagination */}
          <div className="flex items-center gap-1.5 px-1">
            {FEATURED_ANNOUNCEMENTS.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  index === currentIndex ? "w-6 bg-[#f4811f]" : "w-2.5 bg-orange-300"
                }`}
                title={`Go to slide ${index + 1}`}
              />
            ))}
          </div>

          {/* Next Arrow */}
          <button
            onClick={nextSlide}
            className="h-8 w-8 rounded-lg border border-orange-500/20 text-[#f4811f] bg-white hover:bg-orange-50 transition flex items-center justify-center p-0"
            title="Next Notice"
          >
            <ArrowRight size={14} />
          </button>
        </div>

        {/* View All Button */}
        <button
          onClick={() => onViewChange("programmes")}
          className="text-xs font-bold text-[#f4811f] hover:underline bg-transparent border-0 cursor-pointer"
        >
          View All Programmes &rarr;
        </button>
      </div>
    </div>
  );
}
