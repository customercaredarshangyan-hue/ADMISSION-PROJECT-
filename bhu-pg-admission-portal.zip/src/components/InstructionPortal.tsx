import { HelpCircle, Mail, AlertTriangle, Monitor, Landmark } from "lucide-react";

export default function InstructionPortal() {
  return (
    <div className="card shadow rounded-2xl border-0 overflow-hidden min-card-h-600 bg-white">
      {/* Header banner matching original styling */}
      <div className="card-header px-5 py-4 bg-white border-bottom d-flex justify-content-between align-items-center">
        <h5 className="fw-bold mb-0 text-gray-900 text-sm md:text-base font-headline uppercase select-none">
          Admission Portal Instructions
        </h5>
      </div>

      <div className="card-body px-5 py-4">
        {/* Logo and branding centered */}
        <div className="text-center my-4 select-none">
          <img
            src="https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Banaras_Hindu_University_Logo.svg/512px-Banaras_Hindu_University_Logo.svg.png"
            alt="BHU Brand Logo"
            className="img-fluid mx-auto mb-3"
            style={{ height: "65px", objectFit: "contain" }}
          />
          <h5 className="font-bold text-[#3e1300] text-sm md:text-[15px] mb-1 font-headline">
            Banaras Hindu University
          </h5>
          <p className="text-gray-400 text-[10px] md:text-[11px] font-semibold uppercase tracking-wide">
            PG Admission Combined Allotment Program (CAP-PG) 2026-27
          </p>
        </div>

        <hr className="my-6 border-gray-100" />

        {/* Detailed important policy instructions */}
        <div className="space-y-4">
          <div className="flex gap-2.5 items-center mb-3">
            <span className="p-1 px-2.5 bg-orange-500/10 text-orange-600 font-bold text-xs rounded-full">
              !
            </span>
            <h6 className="font-bold text-danger text-[13px] md:text-sm tracking-wide uppercase m-0 font-headline">
              IMPORTANT INSTRUCTIONS FOR CUET-PG (2026)
            </h6>
          </div>

          <ol className="list-decimal pl-5 text-gray-700 text-xs md:text-[13px] space-y-3 leading-relaxed">
            <li>
              Admission to PG Programs of BHU will be based on the scores obtained in <strong>CUET (PG) – 2026</strong>. BHU follows the integrated <strong>Combined Allotment Program [CAP (PG) – 2026]</strong>.
            </li>
            <li>
              Candidates must ensure they selected <strong>BHU</strong> while filling the primary CUET 2026 application form on the NTA website and appeared in the relevant subject test.
            </li>
            <li>
              Candidates are required to carefully read these resources before proceeding:
              <ul className="list-disc pl-5 mt-1.5 space-y-1 text-gray-500 font-medium">
                <li>NTA CUET (PG) Official Information Bulletin</li>
                <li>BHU PG Information Bulletin (PGIB-2026)</li>
                <li>CAP (PG) – 2026 Allocation Guidelines</li>
              </ul>
            </li>
            <li>
              <strong>Admission Eligibility Criteria in matching details:</strong>
              <ul className="list-disc pl-5 mt-1.5 space-y-1 text-gray-500 font-medium">
                <li>Subjects chosen in CUET (PG) corresponding with graduation</li>
                <li>NTA Entrance exam normalized scores</li>
                <li>Subjects studied specifically in undergraduate years</li>
                <li>Qualifying graduation marks percentage (CGPA converted to equivalent %)</li>
              </ul>
            </li>
            <li>
              Personal details (DOB, Gender, Category, Parents name) and subject code selection must match NTA records exactly. <span className="text-red-500 font-semibold">Any mismatches may cause immediate registration rejection.</span>
            </li>
            <li>
              Registration requires a valid registered <strong>NTA Application Number</strong>.
            </li>
            <li>
              Keep scanned copies of these documents ready (&lt;1024 KB in JPEG/PDF format):
              <ul className="list-disc pl-5 mt-1.5 space-y-1 text-gray-200">
                <li className="text-gray-500">Class 10th and 12th authentic Marksheets</li>
                <li className="text-gray-500">Graduation Marksheets (Individual or consolidated up to last exam)</li>
                <li className="text-gray-500">Government Birth Certificate or DOB proof (10th pass)</li>
                <li className="text-gray-500">Category Certs / PwBD Certs / Sports quota docs if active</li>
              </ul>
            </li>
            <li>
              Registration fee is strictly <strong>non-refundable</strong> and must be deposited using online digital gates (Net Banking/UPI/Debit Card).
            </li>
          </ol>

          {/* Aggregate fee catalog tables */}
          <div className="table-responsive my-5 overflow-hidden border border-gray-100 rounded-xl shadow-xs">
            <table className="table table-bordered text-center align-middle mb-0 text-xs md:text-[13px] bg-slate-50/50">
              <thead className="table-light bg-gray-50 border-bottom">
                <tr className="text-gray-700 font-bold">
                  <th className="py-2.5">Category</th>
                  <th className="py-2.5">Registration Fee / Program</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr className="hover:bg-white transition-colors">
                  <td className="py-2.5 text-gray-600 font-medium">UR / OBC-NCL / EWS</td>
                  <td className="py-2.5 text-slate-800 font-bold">₹300 <span className="text-gray-400 font-normal text-[11px]">(Rupees Three Hundred only)</span></td>
                </tr>
                <tr className="hover:bg-white transition-colors">
                  <td className="py-2.5 text-gray-600 font-medium">SC / ST / PwBD</td>
                  <td className="py-2.5 text-slate-800 font-bold">₹150 <span className="text-gray-400 font-normal text-[11px]">(Rupees One Hundred Fifty only)</span></td>
                </tr>
              </tbody>
            </table>
          </div>

          <ol start={9} className="list-decimal pl-5 text-gray-700 text-xs md:text-[13px] space-y-2.5 leading-relaxed">
            <li>
              Verify exact minimum/maximum age eligibility from the official BHU PGIB-2026 bulletin based on course selection before payment.
            </li>
            <li className="flex gap-2 items-center text-amber-700 font-medium bg-amber-500/10 p-2.5 rounded-lg border border-amber-500/15">
              <Monitor size={16} className="text-amber-600 flex-shrink-0" />
              <span>Use a <strong>Desktop/Laptop</strong> for a safer counseling preference submission environment.</span>
            </li>
            <li className="flex gap-2 items-start text-indigo-800 font-medium bg-indigo-500/10 p-2.5 rounded-lg border border-indigo-500/15">
              <Mail size={16} className="text-indigo-600 mt-0.5 flex-shrink-0" />
              <div>
                <span>Admission Helpdesk: </span>
                <a href="mailto:admission.help@bhu.ac.in" className="underline font-bold text-[#f4811f]">
                  admission.help@bhu.ac.in
                </a>
              </div>
            </li>
            <li>
              <strong>Portal Registration Deadline:</strong><br />
              <span className="text-red-500 font-bold">June 04, 2026</span>
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
}
