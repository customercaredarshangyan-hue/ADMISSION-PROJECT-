import { useState, FormEvent } from "react";
import { LogIn, UserPlus, ShieldCheck, Landmark, HelpCircle, Lock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface LockScreenProps {
  onLoginSuccess: (name: string) => void;
}

export default function LockScreen({ onLoginSuccess }: LockScreenProps) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");

  // Login States
  const [appNumber, setAppNumber] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Register States
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regAppNumber, setRegAppNumber] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [regError, setRegError] = useState("");

  const handleLoginSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!appNumber.trim() || !password.trim()) {
      setLoginError("Please enter both NTA Application Number and Password.");
      return;
    }
    // Simulate candidate lookup
    const name = regName.trim() || "Aman Kumar Sharma";
    onLoginSuccess(name);
    setAppNumber("");
    setPassword("");
    setLoginError("");
  };

  const handleRegisterSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim() || !regAppNumber.trim() || !regPassword.trim()) {
      setRegError("All fields must be fully completed.");
      return;
    }
    if (!termsAccepted) {
      setRegError("Please consent to the eligibility norms and terms of verification.");
      return;
    }

    // Register success simulated -> auto-log in!
    onLoginSuccess(regName.trim());
    setRegError("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950 font-sans select-none overflow-y-auto">
      {/* Decorative ambient background glows */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-600/5 rounded-full blur-[150px] pointer-events-none" />

      {/* Grid background mask for a high-tech academic feel */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-35" />

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative w-full max-w-lg my-8 z-10"
      >
        {/* Top Lock Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-[11px] font-bold tracking-wider uppercase">
            <Lock size={12} className="animate-pulse" /> SECRET ADMISSIONS GATEWAY
          </div>
        </div>

        {/* Brand Container */}
        <div className="text-center mb-8">
          <img
            src="https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Banaras_Hindu_University_Logo.svg/512px-Banaras_Hindu_University_Logo.svg.png"
            alt="BHU Logo"
            className="h-20 w-auto mx-auto drop-shadow-[0_0_20px_rgba(244,129,31,0.2)] mb-4"
          />
          <h2 className="text-xl md:text-2xl font-bold text-white font-headline tracking-wide m-0">
            Banaras Hindu University
          </h2>
          <p className="text-gray-400 uppercase tracking-widest text-[9px] md:text-[10px] mt-2 font-semibold font-mono">
            PG Admission Combined Allotment Program (CAP-PG) 2026
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-slate-900/80 backdrop-blur-lg border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          {/* Custom Tabs */}
          <div className="flex border-b border-slate-800 p-1.5 bg-slate-950/40">
            <button
              type="button"
              onClick={() => {
                setActiveTab("login");
                setLoginError("");
                setRegError("");
              }}
              className={`flex-1 py-3 text-xs font-bold tracking-wider text-center uppercase rounded-xl transition-all cursor-pointer ${
                activeTab === "login"
                  ? "bg-[#f4811f] text-white shadow-lg"
                  : "text-gray-400 hover:text-white bg-transparent hover:bg-slate-800/40"
              }`}
            >
              <span className="flex items-center justify-center gap-2">
                <LogIn size={14} /> Registered Candidate Log In
              </span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab("register");
                setLoginError("");
                setRegError("");
              }}
              className={`flex-1 py-3 text-xs font-bold tracking-wider text-center uppercase rounded-xl transition-all cursor-pointer ${
                activeTab === "register"
                  ? "bg-[#f4811f] text-white shadow-lg"
                  : "text-gray-400 hover:text-white bg-transparent hover:bg-slate-800/40"
              }`}
            >
              <span className="flex items-center justify-center gap-2">
                <UserPlus size={14} /> New Registration
              </span>
            </button>
          </div>

          <div className="p-6 md:p-8">
            <AnimatePresence mode="wait">
              {activeTab === "login" ? (
                <motion.form
                  key="login-form"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.2 }}
                  onSubmit={handleLoginSubmit}
                  className="space-y-5"
                >
                  <p className="text-gray-400 text-xs leading-relaxed">
                    Credentials required: Log in with the official application details submitted during matching NTA test domain phases.
                  </p>

                  {loginError && (
                    <div className="p-3 bg-red-500/10 text-red-400 rounded-xl text-xs font-semibold border border-red-500/20">
                      {loginError}
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                      NTA CUET-PG Application No.
                    </label>
                    <input
                      type="text"
                      value={appNumber}
                      onChange={(e) => setAppNumber(e.target.value)}
                      placeholder="e.g., 26351002345"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 transition-all outline-none"
                      required
                    />
                    <span className="text-[10px] text-gray-500 block">
                      Specified in your NTA official scorecard
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                      Portal Password
                    </label>
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter counseling portal password"
                      className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 transition-all outline-none"
                      required
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 px-6 rounded-xl text-xs tracking-widest uppercase transition-all shadow-lg shadow-orange-600/15 cursor-pointer flex items-center justify-center gap-2"
                    >
                      SECURE LOGIN &rarr;
                    </button>
                  </div>
                </motion.form>
              ) : (
                <motion.form
                  key="register-form"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  onSubmit={handleRegisterSubmit}
                  className="space-y-4"
                >
                  <p className="text-gray-400 text-xs leading-relaxed">
                    Verify your eligibility norms and register your counseling portal account dynamically.
                  </p>

                  {regError && (
                    <div className="p-3 bg-red-500/10 text-red-400 rounded-xl text-xs font-semibold border border-red-500/20">
                      {regError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                        Full Name
                      </label>
                      <input
                        type="text"
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="As in NTA Admit Card"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 transition-all outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={regEmail}
                        onChange={(e) => setRegEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 transition-all outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                        NTA CUET Application No.
                      </label>
                      <input
                        type="text"
                        value={regAppNumber}
                        onChange={(e) => setRegAppNumber(e.target.value)}
                        placeholder="11-digit number"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 transition-all outline-none"
                        required
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold text-gray-300 uppercase tracking-wider block">
                        Portal Password
                      </label>
                      <input
                        type="password"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="Set Portal Password"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-orange-500 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 transition-all outline-none"
                        required
                      />
                    </div>
                  </div>

                  {/* Consent Terms Checklist */}
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-xl">
                    <div className="flex items-start gap-2.5">
                      <input
                        type="checkbox"
                        id="lockAcceptTerms"
                        checked={termsAccepted}
                        onChange={(e) => setTermsAccepted(e.target.checked)}
                        className="mt-1 accent-orange-500 cursor-pointer h-4 w-4 text-orange-600 border-slate-800 bg-slate-950 rounded focus:ring-0 focus:ring-offset-0"
                      />
                      <label htmlFor="lockAcceptTerms" className="text-gray-400 text-[10px] md:text-xs leading-relaxed cursor-pointer select-none">
                        I declare that I have selected <strong>Banaras Hindu University</strong> in my NTA application form, appeared in correct test papers, and fulfill the qualifying graduation criteria.
                      </label>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3 px-6 rounded-xl text-xs tracking-widest uppercase transition-all shadow-lg shadow-orange-600/15 cursor-pointer flex items-center justify-center gap-2"
                    >
                      REGISTER CANDIDATE ACCOUNT
                    </button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Footer info lock indicator */}
        <div className="text-center mt-6 text-gray-500 text-[10px] md:text-xs flex items-center justify-center gap-2">
          <ShieldCheck size={14} className="text-green-500" />
          Qualified SSL Certificate Encrypted Gateway • 100% Genuine Admission Domain
        </div>
      </motion.div>
    </div>
  );
}
