import { Clock, ExternalLink } from "lucide-react";
import { PublicNotice } from "../data";

interface NoticeBoardProps {
  notices: PublicNotice[];
  readNoticeIds: string[];
  onMarkAsRead: (id: string) => void;
}

export default function NoticeBoard({ notices, readNoticeIds, onMarkAsRead }: NoticeBoardProps) {
  return (
    <div className="card border-0 shadow rounded-2xl min-card-h-600 bg-white">
      {/* Header */}
      <div className="card-header px-5 py-4 bg-white border-bottom flex justify-between items-center select-none">
        <h5 className="fw-bold mb-0 text-gray-900 text-sm md:text-base font-headline uppercase">
          Public Notices
        </h5>
        <span className="bg-[#f1f5f9] text-[#3e1300] text-[10px] md:text-xs font-bold px-3 py-1 rounded-lg">
          Live Updates
        </span>
      </div>

      {/* Body with announcement list */}
      <div className="card-body p-0 divide-y divide-gray-100">
        {notices.map((notice) => {
          const isRead = readNoticeIds.includes(notice.id);

          return (
            <div 
              key={notice.id} 
              className="p-5 hover:bg-slate-50/50 transition-colors"
              onClick={() => onMarkAsRead(notice.id)}
            >
              {/* Clock and Meta */}
              <div className="flex items-center gap-2 text-gray-400 text-[11px] mb-2 font-medium">
                <Clock size={12} className="flex-shrink-0" />
                <span>Published &bull; {notice.date} ({notice.dateLabel})</span>
              </div>

              {/* Title with live red dot indicator */}
              <div className="flex justify-between items-start gap-4">
                <h6 className="font-semibold text-gray-900 text-sm leading-relaxed tracking-tight font-headline flex-1">
                  {notice.title}
                </h6>
                {!isRead && (
                  <span 
                    className="h-2 w-2 rounded-full bg-red-600 flex-shrink-0 mt-1.5 animate-pulse" 
                    title="Unread Notice" 
                  />
                )}
              </div>

              {/* Action trigger button matching classes exactly */}
              <div className="mt-3">
                <a
                  href={notice.documentUrl}
                  onClick={(e) => {
                    e.stopPropagation(); // Avoid double reads
                    onMarkAsRead(notice.id);
                  }}
                  className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all text-decoration-none border-0 cursor-pointer ${
                    isRead 
                      ? "bg-gray-100 hover:bg-gray-200 text-gray-700" 
                      : "bg-[#f4811f]/10 hover:bg-[#f4811f]/20 text-[#f4811f]"
                  }`}
                >
                  <span>Read Notice</span>
                  <ExternalLink size={12} />
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
