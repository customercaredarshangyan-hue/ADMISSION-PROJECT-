import { useState } from "react";
import { Search, X, Link, Anchor } from "lucide-react";

interface UsefulLinksSearchProps {
  onViewChange: (view: string) => void;
}

interface UsefulLinkItem {
  label: string;
  view?: string;
  externalUrl?: string;
}

const USEFUL_LINKS: UsefulLinkItem[] = [
  { label: "Public Notices", view: "home" },
  { label: "Browse Programmes", view: "programmes" },
  { label: "Eligibility Programme List", view: "eligibility" },
  { label: "Help Center (FAQs)", view: "help-center" },
  { label: "Contact Us", view: "contact" },
  { label: "Prospectus Bulletin", externalUrl: "https://api.bhu.edu.in/uploads/PG_Bulletin_2026_Final_compressed_26f59826df.pdf" },
  { label: "University Website", externalUrl: "https://bhu.ac.in" },
];

export default function UsefulLinksSearch({ onViewChange }: UsefulLinksSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleLinkClick = (link: UsefulLinkItem) => {
    if (link.externalUrl) {
      window.open(link.externalUrl, "_blank", "noopener,noreferrer");
    } else if (link.view) {
      onViewChange(link.view);
    }
  };

  // Filter links
  const filteredLinks = USEFUL_LINKS.filter((link) =>
    link.label.toLowerCase().includes(searchQuery.toLowerCase().trim())
  );

  // Helper to highlight searched terms
  const renderHighlightedText = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, "gi"));
    return (
      <span>
        {parts.map((part, i) =>
          part.toLowerCase() === query.toLowerCase() ? (
            <mark key={i} className="bg-orange-500/10 text-orange-600 font-bold px-1 rounded-sm">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  return (
    <div className="card shadow rounded-2xl border-0 overflow-hidden bg-white mb-6">
      
      {/* Header with search */}
      <div className="card-header px-5 py-4 bg-white border-bottom flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div>
          <h5 className="fw-bold mb-0 text-gray-900 text-sm md:text-base font-headline uppercase select-none">
            <span className="opacity-40 italic font-normal text-xs md:text-sm">A few more &bull; </span>
            Useful Links
          </h5>
        </div>

        {/* Dynamic Search Box */}
        <div className="relative w-full sm:w-64">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search_links form-control"
            placeholder="Search links..."
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-gray-400">
            {searchQuery ? (
              <button
                onClick={() => setSearchQuery("")}
                className="p-1 hover:text-gray-600 rounded bg-transparent border-0 cursor-pointer"
                title="Clear query"
              >
                <X size={15} />
              </button>
            ) : (
              <Search size={15} />
            )}
          </div>
        </div>
      </div>

      {/* Body with filtered list */}
      <div className="card-body p-6">
        {filteredLinks.length > 0 ? (
          <div>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">
              Portal Directory Search Index
            </p>
            <div className="flex flex-wrap gap-2.5">
              {filteredLinks.map((link, idx) => (
                <button
                  key={idx}
                  onClick={() => handleLinkClick(link)}
                  className="search-badge bg-gray-50 hover:bg-orange-500/10 hover:border-orange-500/20 text-slate-800 text-xs font-semibold py-2.5 px-4 rounded-xl border border-gray-200 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Anchor size={12} className="text-orange-500 flex-shrink-0" />
                  <span className="search-text">
                    {renderHighlightedText(link.label, searchQuery)}
                  </span>
                  <span className="text-gray-400 font-bold ml-1">&rarr;</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400 select-none">
            <p className="font-bold text-xs uppercase tracking-wider mb-1">No Result Found</p>
            <p className="text-xs text-gray-400 font-medium">Try verifying your search keyword terms.</p>
          </div>
        )}
      </div>

    </div>
  );
}
