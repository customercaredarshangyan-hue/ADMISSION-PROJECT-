import { useState } from "react";
import { 
  HelpCircle, 
  Bell, 
  Menu, 
  X, 
  BookOpen, 
  ArrowRight, 
  Grid, 
  FileText, 
  Globe, 
  Contact 
} from "lucide-react";

interface HeaderProps {
  onViewChange: (view: string) => void;
  activeView: string;
  unreadCount: number;
  onOpenLogin: () => void;
  onOpenRegister: () => void;
}

export default function Header({ 
  onViewChange, 
  activeView, 
  unreadCount, 
  onOpenLogin, 
  onOpenRegister 
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const navigateTo = (view: string) => {
    onViewChange(view);
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-white border-bottom py-2 shadow-sm sticky-top">
      <div className="max-w-7xl mx-auto w-full px-4 flex align-items-center justify-between">
        
        {/* Brand Logo & Name */}
        <button
          onClick={() => navigateTo("home")}
          className="navbar-brand d-flex align-items-center gap-2 border-0 bg-transparent p-0 text-start flex-shrink-0 cursor-pointer"
        >
          <img
            src="https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Banaras_Hindu_University_Logo.svg/512px-Banaras_Hindu_University_Logo.svg.png"
            alt="BHU Logo"
            className="img-fluid"
            style={{ height: "45px", objectFit: "contain" }}
          />
          <div className="lh-sm text-wrap max-w-sm">
            <div className="font-bold text-[#3e1300] text-sm md:text-[15px] leading-tight font-headline">
              Banaras Hindu University
            </div>
            <div className="text-gray-500 uppercase tracking-wide text-[9px] md:text-[10px] mt-1 font-semibold">
              PG Admission Combined Allotment Program (CAP-PG) 2026-27
            </div>
          </div>
        </button>

        {/* Deskop Navigation Items */}
        <div className="hidden lg:flex items-center gap-2 md:gap-4 flex-nowrap">
          {/* Help Center */}
          <button
            onClick={() => navigateTo("help-center")}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeView === "help-center"
                ? "bg-[#f4811f]/10 text-[#f4811f]"
                : "text-gray-700 hover:bg-slate-100"
            }`}
          >
            Help Center <HelpCircle size={15} />
          </button>

          {/* Public Notice */}
          <button
            onClick={() => navigateTo("home")}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold relative transition-all ${
              activeView === "notices"
                ? "bg-[#f4811f]/10 text-[#f4811f]"
                : "text-gray-700 hover:bg-slate-100"
            }`}
          >
            Public Notice <Bell size={15} />
            {unreadCount > 0 && (
              <span className="absolute -top-1.5 -right-1 bg-red-600 text-white rounded-full text-[9px] font-bold h-4 w-4 flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>

          {/* More Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-gray-700 hover:bg-slate-100 transition-all border-none"
            >
              More <Grid size={15} />
            </button>

            {moreDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-40 bg-transparent" 
                  onClick={() => setMoreDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-64 bg-white border border-gray-200 rounded-xl shadow-xl z-50 py-3 overflow-hidden animate-fade-in">
                  <div className="px-4 mb-2">
                    <p className="text-[10px] font-bold text-gray-400 tracking-widest uppercase">Applications</p>
                  </div>
                  <button 
                    onClick={() => navigateTo("programmes")}
                    className="w-full text-left px-4 py-2 text-xs text-gray-700 hover:bg-slate-50 transition flex items-center gap-2"
                  >
                    <BookOpen size={14} className="text-gray-400" />
                    Browse Programmes
                  </button>
                  <button 
                    onClick={() => navigateTo("eligibility")}
                    className="w-full text-left px-4 py-2 text-xs text-gray-700 hover:bg-slate-50 transition flex items-center gap-2"
                  >
                    <FileText size={14} className="text-gray-400" />
                    Eligibility Programme List
                  </button>
                  
                  <div className="border-t border-gray-100 my-2" />
                  
                  <div className="px-4 mb-2">
                    <p className="text-[10px] font-bold text-gray-400 tracking-widest uppercase">Resources</p>
                  </div>
                  <a 
                    href="https://api.bhu.edu.in/uploads/PG_Bulletin_2026_Final_compressed_26f59826df.pdf"
                    target="_blank"
                    rel="noreferrer"
                    className="block px-4 py-2 text-xs text-gray-700 hover:bg-slate-50 transition flex items-center gap-2"
                  >
                    <FileText size={14} className="text-gray-400" />
                    Prospectus & Bulletin
                  </a>
                  <a 
                    href="https://bhu.ac.in" 
                    target="_blank" 
                    rel="noreferrer"
                    className="block px-4 py-2 text-xs text-gray-700 hover:bg-slate-50 transition flex items-center gap-2"
                  >
                    <Globe size={14} className="text-gray-400" />
                    University Main Website
                  </a>

                  <div className="border-t border-gray-100 my-2" />
                  
                  <div className="px-4 mb-2">
                    <p className="text-[10px] font-bold text-gray-400 tracking-widest uppercase">Support</p>
                  </div>
                  <button 
                    onClick={() => navigateTo("contact")}
                    className="w-full text-left px-4 py-2 text-xs text-gray-700 hover:bg-slate-50 transition flex items-center gap-2"
                  >
                    <Contact size={14} className="text-gray-400" />
                    Contact Helpdesk
                  </button>
                </div>
              </>
            )}
          </div>

          <div className="border-l border-gray-200 h-6 mx-1" />

          {/* Login & Register Buttons */}
          <button
            onClick={onOpenLogin}
            className="px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold transition shadow-sm"
          >
            Login
          </button>
          <button
            onClick={onOpenRegister}
            className="px-4.5 py-2.5 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1 transition shadow-md"
          >
            Register <ArrowRight size={13} />
          </button>
        </div>

        {/* Mobile Menu Action Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg lg:hidden"
        >
          {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile Drawer menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-gray-200 bg-white px-4 py-4 space-y-3 shadow-inner">
          <button
            onClick={() => navigateTo("help-center")}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 flex items-center justify-between"
          >
            <span>Help Center</span>
            <HelpCircle size={16} />
          </button>

          <button
            onClick={() => navigateTo("home")}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 flex items-center justify-between"
          >
            <span>Public Notices</span>
            <Bell size={16} />
          </button>

          <button
            onClick={() => navigateTo("programmes")}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 flex items-center justify-between"
          >
            <span>Browse Programmes</span>
            <BookOpen size={16} />
          </button>

          <button
            onClick={() => navigateTo("eligibility")}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 flex items-center justify-between"
          >
            <span>Eligibility Criteria</span>
            <FileText size={16} />
          </button>

          <button
            onClick={() => navigateTo("contact")}
            className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 flex items-center justify-between"
          >
            <span>Contact Helpdesk</span>
            <Contact size={16} />
          </button>

          <div className="border-t border-gray-100 my-4" />

          {/* Authentication inside mobile drawer */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenLogin();
              }}
              className="py-2.5 px-4 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-800 text-sm font-bold text-center"
            >
              Login
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenRegister();
              }}
              className="py-2.5 px-4 rounded-full bg-slate-900 hover:bg-slate-800 text-white text-sm font-bold text-center flex items-center justify-center gap-1"
            >
              Register <ArrowRight size={15} />
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
