import { useState, FormEvent } from "react";
import { Mail, Phone, MapPin, Send, HelpCircle, ShieldCheck } from "lucide-react";

export default function ContactView() {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userQuery, setUserQuery] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim() || !userQuery.trim()) return;
    
    // Simulate submission
    setSubmitted(true);
    setUserName("");
    setUserEmail("");
    setUserQuery("");
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      
      {/* Contact Header */}
      <div className="bg-[#3e1300] text-white rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden select-none">
        <div className="absolute right-0 top-0 w-36 h-36 bg-orange-400 rounded-full blur-[50px] opacity-35" />
        <h3 className="text-xl md:text-2xl font-bold font-headline mb-2 flex items-center gap-2">
          Contact Admission Helpdesk
        </h3>
        <p className="text-white/85 text-xs md:text-sm max-w-2xl leading-relaxed">
          Need prompt resolution? Contact the Central Admission Committee, BHU directly or post your grievances using our counseling query box.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        
        {/* Helpdesk Coordinates Card */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 space-y-6 shadow-sm">
          <h4 className="font-bold text-[#3e1300] text-sm md:text-base font-headline uppercase select-none pb-2 border-b">
            Official Coordinates
          </h4>

          <div className="space-y-4">
            {/* Address */}
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-orange-500/10 text-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <MapPin size={18} />
              </div>
              <div className="text-xs md:text-sm">
                <p className="text-gray-400 font-bold uppercase text-[10px]">Headquarters Address</p>
                <p className="text-gray-800 font-semibold mt-0.5">Central Admission Office</p>
                <p className="text-gray-600 mt-1">Banaras Hindu University, Varanasi, Uttar Pradesh-221005, INDIA</p>
              </div>
            </div>

            {/* Email */}
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-orange-500/10 text-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <Mail size={18} />
              </div>
              <div className="text-xs md:text-sm">
                <p className="text-gray-400 font-bold uppercase text-[10px]">Helpline Email</p>
                <p className="text-gray-800 font-semibold mt-0.5">admission.help@bhu.ac.in</p>
                <p className="text-gray-500 mt-1">Grievances or query resolutions are addressed from 10:00 AM to 5:30 PM on workdays.</p>
              </div>
            </div>

            {/* Helpline lines */}
            <div className="flex gap-3">
              <div className="h-10 w-10 bg-orange-500/10 text-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <Phone size={18} />
              </div>
              <div className="text-xs md:text-sm">
                <p className="text-gray-400 font-bold uppercase text-[10px]">Helpline Office Lines</p>
                <p className="text-gray-800 font-semibold mt-0.5">+91 542 2368558, 2368456</p>
                <p className="text-gray-500 mt-1">Operational during counseling cycles. Busy tones are common, please drop emails for swift tracking.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Query submission form */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          <h4 className="font-bold text-[#3e1300] text-sm md:text-base font-headline uppercase select-none pb-2 border-b">
            Counseling Query Ticket
          </h4>

          {submitted ? (
            <div className="py-12 text-center text-green-600 flex flex-col items-center justify-center space-y-3">
              <div className="h-14 w-14 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center border border-green-500/25">
                <ShieldCheck size={28} />
              </div>
              <p className="font-bold text-gray-900 text-sm">Query Submitted Successfully!</p>
              <p className="text-gray-500 text-xs max-w-xs leading-relaxed">
                We have registered your counseling ticket under tracking ref #BHU9954-2026. A resolution will be sent to your inbox.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div className="space-y-1">
                <label className="form-label">Full Candidate Name</label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Enter your name"
                  className="form-control"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="form-label">Email ID</label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="form-control"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="form-label">Grievance / Counseling Query Details</label>
                <textarea
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                  placeholder="State your query clearly (mention NTA Score Card / Application number if applicable)"
                  className="form-control custom-textarea"
                  required
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="btn bg-[#f4811f] hover:bg-[#e07519] text-white font-bold py-2.5 px-6 text-xs tracking-wider flex items-center justify-center gap-2 cursor-pointer w-full"
                >
                  SUBMIT QUERY <Send size={14} />
                </button>
              </div>
            </form>
          )}

        </div>

      </div>

    </div>
  );
}
