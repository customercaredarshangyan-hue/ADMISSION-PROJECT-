/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { Landmark, ShieldAlert, LogOut, CheckCircle, Scale, Volume2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import Topbar from "./components/Topbar";
import Header from "./components/Header";
import InstructionPortal from "./components/InstructionPortal";
import HeroSlider from "./components/HeroSlider";
import ChecklistAndApply from "./components/ChecklistAndApply";
import NoticeBoard from "./components/NoticeBoard";
import UsefulLinksSearch from "./components/UsefulLinksSearch";
import Footer from "./components/Footer";
import ProgrammesList from "./components/ProgrammesList";
import HelpCenter from "./components/HelpCenter";
import ContactView from "./components/ContactView";
import EligibilityView from "./components/EligibilityView";
import AuthModals from "./components/AuthModals";
import LockScreen from "./components/LockScreen";

import { PUBLIC_NOTICES, PublicNotice } from "./data";

export default function App() {
  const [activeView, setActiveView] = useState("home");
  const [fontSizeOffset, setFontSizeOffset] = useState(0);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState<string | null>(null);
  const [readNoticeIds, setReadNoticeIds] = useState<string[]>([]);
  const [showGrievanceDismiss, setShowGrievanceDismiss] = useState(true);

  // Load cookies / LocalStorage states on mount
  useEffect(() => {
    try {
      const storedRead = localStorage.getItem("read_notifications_bhu_pg");
      if (storedRead) {
        setReadNoticeIds(JSON.parse(storedRead));
      }

      const storedUser = localStorage.getItem("bhu_logged_in_candidate");
      if (storedUser) {
        setLoggedInUser(storedUser);
      }
    } catch (e) {
      console.error("Local storage error:", e);
    }
  }, []);

  // Sync clicked notices to local storage and update header badges
  const handleMarkNoticeAsRead = (id: string) => {
    if (readNoticeIds.includes(id)) return;
    const updated = [...readNoticeIds, id];
    setReadNoticeIds(updated);
    try {
      localStorage.setItem("read_notifications_bhu_pg", JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoginSuccess = (name: string) => {
    setLoggedInUser(name);
    try {
      localStorage.setItem("bhu_logged_in_candidate", name);
    } catch (e) {
      console.error(e);
    }
    setActiveView("home");
    setShowLogin(false);
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    try {
      localStorage.removeItem("bhu_logged_in_candidate");
    } catch (e) {
      console.error(e);
    }
  };

  // Determine actual unread notices count
  const allNoticeIds = PUBLIC_NOTICES.map((n) => n.id);
  const unreadCount = allNoticeIds.filter((id) => !readNoticeIds.includes(id)).length;

  if (!loggedInUser) {
    return <LockScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div 
      className="flex flex-col min-h-screen bg-slate-50 transition-all duration-300"
      style={{ fontSize: `${14 + fontSizeOffset}px` }}
    >
      
      {/* Resizing and academic domains top panel */}
      <Topbar fontSizeOffset={fontSizeOffset} setFontSizeOffset={setFontSizeOffset} />

      {/* Main navigation Header */}
      <Header
        onViewChange={setActiveView}
        activeView={activeView}
        unreadCount={unreadCount}
        onOpenLogin={() => setShowLogin(true)}
        onOpenRegister={() => setShowRegister(true)}
      />

      {/* Dynamic View rendering engine */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-8">
        
        {/* Candidate Dashboard welcome alert (if logged in) */}
        {loggedInUser && (
          <div className="bg-green-50 border border-green-500/10 rounded-2xl p-5 mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm select-none">
            <div className="flex items-center gap-3">
              <div className="h-11 w-11 bg-green-500/10 text-green-600 rounded-full flex items-center justify-center border border-green-500/20">
                <CheckCircle size={22} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-gray-900 text-sm md:text-[15px] m-0 font-headline">
                    Candidate Dashboard: {loggedInUser}
                  </h4>
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse" title="Profile Active" />
                </div>
                <p className="text-gray-500 text-xs md:text-[13px] mt-1">
                  Application reference: <code className="text-[#f4811f] font-bold">BHU-PG/2026/0478052</code> &bull; Allotment phase preference submission: <strong>OPEN</strong>
                </p>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg border border-red-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              Sign out <LogOut size={13} />
            </button>
          </div>
        )}

        <AnimatePresence mode="wait">
          {activeView === "home" && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Column 1: Admission Instructions checklist */}
                <div className="lg:col-span-4">
                  <InstructionPortal />
                </div>

                {/* Column 2: Dashboard actions, slider widgets & checklists */}
                <div className="lg:col-span-4 space-y-6">
                  <HeroSlider onViewChange={setActiveView} />
                  <ChecklistAndApply 
                    onOpenLogin={() => setShowLogin(true)} 
                    onOpenRegister={() => setShowRegister(true)} 
                  />
                </div>

                {/* Column 3: Live notices feed board */}
                <div className="lg:col-span-4">
                  <NoticeBoard
                    notices={PUBLIC_NOTICES}
                    readNoticeIds={readNoticeIds}
                    onMarkAsRead={handleMarkNoticeAsRead}
                  />
                </div>

              </div>

              {/* Bottom zero tolerance banner matches original footer layouts */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Ragging Warning Banner inside layout */}
                <div className="lg:col-span-8 bg-[#dc3545]/5 hover:bg-[#dc3545]/10 text-[#dc2626] border-2 border-red-500/10 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-sm transition-all select-none">
                  <div className="flex items-start gap-4">
                    <div className="h-14 w-14 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                      <ShieldAlert size={28} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 text-sm md:text-base mb-1 font-headline">Zero Tolerance for Ragging</h4>
                      <p className="text-gray-500 text-xs md:text-[13px] leading-relaxed">
                        Ragging in any form is totally prohibited in the University campus, hostels, or libraries. Offenders are liable to immediate expulsion and police action.
                      </p>
                    </div>
                  </div>
                  <a
                    href="https://www.antiragging.in"
                    target="_blank"
                    rel="noreferrer"
                    className="btn bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 px-5 text-xs text-decoration-none shadow"
                  >
                    Anti Ragging Portal &rarr;
                  </a>
                </div>

                {/* Need Assistance Card */}
                <div className="lg:col-span-4 bg-orange-500/10 hover:bg-orange-500/15 border-2 border-orange-500/15 rounded-2xl p-6 flex flex-col justify-between shadow-sm transition-all text-[#3e1300] select-none">
                  <div>
                    <h5 className="font-bold text-sm md:text-[15px] font-headline mb-1">Need Assistance?</h5>
                    <p className="text-gray-600 text-xs leading-relaxed mt-2.5">
                      Our official counseling support is operational during corporate office timings. Feel free to contact our coordinator committee.
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveView("contact")}
                    className="mt-6 btn bg-[#3e1300] hover:bg-[#2d0a00] text-white font-bold py-2 px-4 text-xs cursor-pointer text-center w-full"
                  >
                    Contact Admission Desk
                  </button>
                </div>
              </div>

              {/* Keyword filtering useful links board */}
              <UsefulLinksSearch onViewChange={setActiveView} />

            </motion.div>
          )}

          {activeView === "programmes" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <ProgrammesList />
            </motion.div>
          )}

          {activeView === "eligibility" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <EligibilityView />
            </motion.div>
          )}

          {activeView === "help-center" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <HelpCenter />
            </motion.div>
          )}

          {activeView === "contact" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <ContactView />
            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* Main Government guidelines and BHU Footer */}
      <Footer onViewChange={setActiveView} />

      {/* Login & Register modals wrapper */}
      <AuthModals
        showLogin={showLogin}
        showRegister={showRegister}
        onCloseLogin={() => setShowLogin(false)}
        onCloseRegister={() => setShowRegister(false)}
        onLoginSuccess={handleLoginSuccess}
      />

    </div>
  );
}

