export interface PublicNotice {
  id: string;
  title: string;
  date: string;
  dateLabel: string;
  documentUrl: string;
  featured?: boolean;
}

export interface Programme {
  code: string;
  name: string;
  degree: string;
  department: string;
  duration: string;
  eligibility: string;
  fee: string;
  testSubjects: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export const FEATURED_ANNOUNCEMENTS: PublicNotice[] = [
  {
    id: "21",
    title: "PG Admission Information Bulletin 2026",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
    featured: true,
  },
  {
    id: "22",
    title: "CAP PG 2026 Guidelines & Combined Allotment",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
    featured: true,
  },
  {
    id: "23",
    title: "BHU Registration Public Notice 2026",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
    featured: true,
  },
];

export const PUBLIC_NOTICES: PublicNotice[] = [
  {
    id: "23",
    title: "BHU Registration Public Notice 2026",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
  },
  {
    id: "22",
    title: "CAP PG 2026 Guidelines & Procedures",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
  },
  {
    id: "21",
    title: "PG Admission Information Bulletin 2026",
    date: "20-May-2026",
    dateLabel: "12 days ago",
    documentUrl: "#",
  },
  {
    id: "20",
    title: "Public Notice for Reservation Criteria under CAP-PG 2026",
    date: "18-May-2026",
    dateLabel: "14 days ago",
    documentUrl: "#",
  },
  {
    id: "19",
    title: "Extension of Last Date of Registration for CAP-PG (2026)",
    date: "15-May-2026",
    dateLabel: "17 days ago",
    documentUrl: "#",
  },
];

export const BHU_PROGRAMMES: Programme[] = [
  {
    code: "PG001",
    name: "M.Sc. in Computer Science",
    degree: "Master of Science",
    department: "Department of Computer Science",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.Sc. (Hons.) / B.Sc. under 10+2+3 pattern securing a minimum of 50% marks in the aggregate in Science subjects (including Computer Science on par with other core science subjects) or equivalent.",
    fee: "₹6,500 per semester",
    testSubjects: "Computer Science & Information Technology (SCQP09)",
  },
  {
    code: "PG002",
    name: "M.Sc. in Physics",
    degree: "Master of Science",
    department: "Department of Physics",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.Sc. (Hons.)/ B.Sc. under 10+2+3 pattern securing a minimum of 50% marks in the aggregate in Science subjects (Physics must be a subject studied in all three years of graduation).",
    fee: "₹4,200 per semester",
    testSubjects: "Physics (SCQP24)",
  },
  {
    code: "PG003",
    name: "M.Sc. in Chemistry",
    degree: "Master of Science",
    department: "Department of Chemistry",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.Sc. (Hons.)/ B.Sc. under 10+2+3 pattern securing a minimum of 50% marks in the aggregate in Science subjects with Chemistry studied in all graduation years.",
    fee: "₹4,200 per semester",
    testSubjects: "Chemistry (SCQP08)",
  },
  {
    code: "PG004",
    name: "M.Sc. in Biotechnology",
    degree: "Master of Science",
    department: "School of Biotechnology",
    duration: "2 Years (4 Semesters)",
    eligibility: "Bachelor's degree under 10+2+3 pattern in Physical, Biological, Agricultural, Veterinary and Fishery Sciences, Pharmacy, Engineering/Technology, 4-years B.Sc. (Physician Assistant Course) or Medicine (MBBS) with at least 50% marks.",
    fee: "₹18,500 per semester (Paid seat)",
    testSubjects: "Agricultural Biotechnology / Biotechnology (SCQP17)",
  },
  {
    code: "PG005",
    name: "M.A. in Economics",
    degree: "Master of Arts",
    department: "Department of Economics",
    duration: "2 Years (4 Semesters)",
    eligibility: "Bachelor's degree under 10+2+3 pattern in any discipline with Economics/Mathematics/Statistics as one of the subjects studied, securing at least 50% marks in aggregate.",
    fee: "₹3,500 per semester",
    testSubjects: "Economics (COQP10)",
  },
  {
    code: "PG006",
    name: "M.A. in English",
    degree: "Master of Arts",
    department: "Department of English",
    duration: "2 Years (4 Semesters)",
    eligibility: "Bachelor's degree under 10+2+3 pattern with English as an Honours subject or main subject at graduation level, securing a minimum of 50% marks in aggregate.",
    fee: "₹3,100 per semester",
    testSubjects: "English (LAQP01)",
  },
  {
    code: "PG007",
    name: "Master of Commerce (M.Com.)",
    degree: "Master of Commerce",
    department: "Department of Commerce",
    duration: "2 Years (4 Semesters)",
    eligibility: "B.Com (Hons.) / B.Com. / B.Com. (Hons.) under 10+2+3 pattern securing a minimum of 50% marks in the aggregate from a recognized university.",
    fee: "₹4,800 per semester",
    testSubjects: "Commerce (COQP08)",
  },
  {
    code: "PG008",
    name: "Master of Computer Applications (MCA)",
    degree: "Master of Computer Applications",
    department: "Department of Computer Science",
    duration: "2 Years (4 Semesters)",
    eligibility: "Passed BCA/ Bachelor Degree in Computer Science Engineering or equivalent Degree. Or Passed B.Sc./ B.Com./ B.A. with Mathematics at 10+2 Level or at Graduation Level (with additional bridge Courses as per the norms of the University) securing at least 50% marks.",
    fee: "₹12,500 per semester",
    testSubjects: "Computer Science and MCA (SCQP09)",
  },
  {
    code: "PG009",
    name: "Master of Laws (LL.M.)",
    degree: "Master of Laws",
    department: "Faculty of Law",
    duration: "2 Years (4 Semesters)",
    eligibility: "3-Year LL.B. after graduation under 10+2+3 pattern or 5-Year Integrated LL.B. under 10+2+5 pattern recognized by Bar Council of India, securing not less than 50% marks in aggregate.",
    fee: "₹6,800 per semester",
    testSubjects: "Law (COQP14)",
  },
  {
    code: "PG010",
    name: "Master of Business Administration (MBA)",
    degree: "Master of Business Administration",
    department: "Institute of Management Studies",
    duration: "2 Years (4 Semesters)",
    eligibility: "Bachelor's degree in any discipline under 10+2+3 pattern with at least 50% marks in aggregate, or Postgraduate degree with at least 50% marks.",
    fee: "₹45,000 per year (Plus Regular Fees)",
    testSubjects: "Business Administration / MBA (COQP12)",
  },
];

export const HELP_CENTER_FAQS: FaqItem[] = [
  {
    id: "1",
    question: "What is Combined Allotment Program (CAP-PG) at BHU?",
    answer: "The CAP-PG is a centralized single-window allotment system conducted by BHU for admissions into all Postgraduate programs based on the scores of CUET (PG) 2026. Applicants must register on this portal to offer their course preferences.",
    category: "General Counseling",
  },
  {
    id: "2",
    question: "Do I need to check my score matching before applying?",
    answer: "Yes, candidates must match their CUET (PG) test paper components with the Eligibility Criteria specified for their desired programs in the BHU PG Information Bulletin. Only relevant CUET test paper code scores are considered.",
    category: "Eligibility Verification",
  },
  {
    id: "3",
    question: "What are the registration fees for the CAP PG 2026 portal?",
    answer: "For General, OBC-NCL, and EWS candidates, the registration fee is ₹300 per program selected. For SC, ST, and PwBD candidates, the registration fee is ₹150 per program. This fee is non-refundable.",
    category: "Payments & Fees",
  },
  {
    id: "4",
    question: "Which documents should be kept ready for registration?",
    answer: "Candidates need scanned copies of their colored photograph, signature, 10th & 12th marksheets, graduation consolidated marksheet (or semester-wise marksheets), and category certificates (OBC-NCL, EWS, SC, ST, PwBD) if applicable. All files should be in JPEG or PDF format under 1MB.",
    category: "Document Verification",
  },
  {
    id: "5",
    question: "Can I edit my program selection after submitting the registration fee?",
    answer: "No. Once the fee is successfully paid, you will not be allowed to add or modify selected programs. Please review your selection and verify eligibility completely before paying.",
    category: "General Counseling",
  },
  {
    id: "6",
    question: "How is CGPA converted to percentage for graduation marks?",
    answer: "You must convert CGPA/CPI to percentage following the official formula of your degree-granting Institution/University. If no official formula is specified, you may use standard conversion systems, but you must upload the explanation certificate.",
    category: "Eligibility Verification",
  },
  {
    id: "7",
    question: "My status is showing 'Paid but pending', what does it mean?",
    answer: "This is a brief intermediate state while banks reconcile payments. If your banking portal indicates the amount has been deducted, do not pay again. Wait up to 24 hours. The status on your dashboard will update soon.",
    category: "Payments & Fees",
  },
];
